package com.example.potaleafscan

data class ApiResponse(
    val prediction: String,
    val confidence: Double
)
